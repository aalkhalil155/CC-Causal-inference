# causal-dragonnet-dummy

Minimal DragonNet-style continuous treatment dummy project.

## Run locally
pip install -r requirements.txt
python -m src.train

## Run in Google Colab
!git clone <YOUR_REPO_URL>
%cd causal-dragonnet-dummy
!pip install -r requirements.txt
!python -m src.train
